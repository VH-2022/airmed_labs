

<style>
.border-search{ background-color: #fff;
    border: 1px solid #000;
    border-radius: 0;
   -- border-top: 1px solid #d01130;
    box-shadow: 1px 1px rgba(0, 0, 0, 0.4);
    clear: left;}
	.indx_big_img {
    width: 100%;
    background-image: url(../images/new/home_1.png);
    background-attachment: fixed;
    background-size: cover;
    height: 480px !important;
    top: 10% !important;
    background-position: 0 80px;
}
</style>
<!-- Start main-content -->
<div class="main-content">
    <!-- Section: home -->


    <section id="about" >
       
		<div class="indx_big_img" style="background-image: url(<?php echo base_url(); ?>user_assets/images/new/about-banner.jpg);">
            <div class="container">
               <div class="row">
					<div class="col-md-6 pull-right">
						<center>
						<h1 class="font-52"> We are <img src="<?php echo base_url(); ?>user_assets/images/new/about-banner-logo.png" style="width:40%"></h1>
						<p>Commited to make a healthy difference</p>
						</center>
					</div>
               </div>
          </div>
        </div>
                   
    </section>

    <!-- Section: Departments  -->
    <section id="depertments" class="bg-white parlx_back">
        <div class="container indx_4_img">
            <div class="section-content "> <!--col-md-10 col-md-offset-1-->
                <div class="row indx_round_div">
				
				<div class="full-width">
                    <div class="col-md-2 col-sm-6 col-xs-6">
                        <div class="icon-box text-center">
                            <div class="col-md-12 col-sm-3 icon-content focus res_indx_cl4_img">
                                <a href="javascript:" class="icon bg-theme-colored icon-circled icon-border-effect effect-circled icon-md hm_mdl_247_a four_img_hvr a_247_res_768media">
                                    <img class="" src="<?php echo base_url(); ?>user_assets/images/new/hometreat.png">
                                </a>
                            </div>
                            <div class="col-md-12 col-sm-9 icon-content focus four_img_mrgntop_20px_768 pdng_0">
                                <span class="icon-box-title res_indx_cl8_title res_focussed new_res_247_spn1_full"><a href="javascript:">Free<br/>Home visit</a></span>
                               <!-- <span class="dark_spn new_res_247_spn2_full">24 x 7</span>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-6">
                        <div class="icon-box text-center">
                            <div class="col-md-12 col-sm-3 icon-content blood res_indx_cl4_img">
                                <a href="javascript:" class="icon bg-theme-colored icon-circled icon-border-effect effect-circled icon-md four_img_hvr img_lctn_res a_lctn_res_768media">
                                    <img class="lctn_img " src="<?php echo base_url(); ?>user_assets/images/new/fastestturn.png">
                                </a>
                            </div>
                            <div class="col-md-12 col-sm-9 icon-content blood four_img_mrgntop_20px_768 pdng_0">
                                <span class="icon-box-title res_indx_cl8_title res_480_loctn"><a href="javascript:" style="">Fastest<br/>Turn Around Time</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-6">
                        <div class="icon-box text-center">
                            <div class="col-md-12 col-sm-3 icon-content weare res_indx_cl4_img">
                                <a href="javascript:" class="icon bg-theme-colored icon-circled icon-border-effect effect-circled icon-md four_img_hvr img_hndmbl_res a_hndmbl_res_768media">
                                    <img class="logo_img " src="<?php echo base_url(); ?>user_assets/images/new/painless.png">
                                </a>
                            </div>
                            <div class="col-md-12 col-sm-9 icon-content weare icon-title four_img_mrgntop_20px_768 pdng_0">
                                <span class="icon-box-title fast_dlvr_txt res_indx_cl8_title" style=""><a href="javascript:">Painless <br/> Testing</a></span>

                            </div>
                        </div>
                    </div>
					<div class="col-md-2 col-sm-6 col-xs-6">
                        <div class="icon-box text-center">
                            <div class="col-md-12 col-sm-3 icon-content weare res_indx_cl4_img">
                                <a href="javascript:" class="icon bg-theme-colored icon-circled icon-border-effect effect-circled icon-md four_img_hvr img_hndmbl_res a_hndmbl_res_768media">
                                    <img class="logo_img " src="<?php echo base_url(); ?>user_assets/images/new/icon4.png">
                                </a>
                            </div>
                            <div class="col-md-12 col-sm-9 icon-content weare icon-title four_img_mrgntop_20px_768 pdng_0">
                                <span class="icon-box-title fast_dlvr_txt res_indx_cl8_title" style=""><a href="javascript:">Accurate  <br/> Test Results</a></span>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-6 res_for_bookng">
                        <div class="icon-box text-center">
                            <div class="col-md-12 col-sm-3 icon-content forbook res_indx_cl4_img">
                                <a href="tel:+91 70 43 21 50 52" class="icon bg-theme-colored icon-circled icon-border-effect effect-circled icon-md four_img_hvr img_ringphn_res a_ringphn_res_768media">
                                    <img class="" src="<?php echo base_url(); ?>user_assets/images/new/24x4.png">
                                </a>
                            </div>
                            <div class="col-md-12 col-sm-9 icon-content forbook four_img_mrgntop_20px_768 pdng_0">
                                <span class="icon-box-title res_indx_cl8_title res_for_bookng_h3 new_res_247_spn1_full"><a href="javascript:">Round The clock <br/>Assistance</a></span>
                                <!--<span class="dark_spn new_res_247_spn2_full" style="">+91 8101161616</span>-->
                            </div>
                        </div>
                    </div>
					 <div class="col-md-2 col-sm-6 col-xs-6 res_for_bookng">
                        <div class="icon-box text-center">
                            <div class="col-md-12 col-sm-3 icon-content forbook res_indx_cl4_img">
                                 <a href="javascript:" class="icon bg-theme-colored icon-circled icon-border-effect effect-circled icon-md hm_mdl_247_a four_img_hvr a_247_res_768media">
                                    <img class="" src="<?php echo base_url(); ?>user_assets/images/new/blood-report.png">
                                </a>
                            </div>
                            <div class="col-md-12 col-sm-9 icon-content forbook four_img_mrgntop_20px_768 pdng_0">
                                <span class="icon-box-title res_indx_cl8_title res_for_bookng_h3 new_res_247_spn1_full"><a href="javascript:">Manage & Maintain<br/>Blood Reports</a></span>
                                <!--<span class="dark_spn new_res_247_spn2_full" style="">+91 8101161616</span>-->
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </section>
<div class="border-btn mt-30 bg-white"><span></span></div>

  <section class="bg-white">
	<div class="container mbl_containr" style="padding-bottom:0">
		<div class="row">
			<div class="col-sm-12">
				 <h1 class="subtitle text-center txt_blue_clr" style="margin-bottom: 25px;color:#333;font-weight:bold">LAB AT YOUR DOORSTEP</h1>
				
				<p>With the focus on providing quality care to our patients, best in class diagnostic support to our doctors, we are a team of dedicated pathologists supported by a highly professional team of business and clinical experts.</p>
				<p>We strive to attain highest levels of service quality to strongly influence patient satisfaction.</p>

				<p>Non-clinical attributes, be it hygiene, waiting areas and level of communication with patients, play a vital role in ensuring patient satisfaction. Unfortunately, the non-clinical aspects are often ignored by most of healthcare providers. At Airmed, we strive to achieve highest levels of patient satisfaction, and at the same time, maintaining foremost levels of clinical standards.
				</p>
			</div>	
		</div>
	</div>
  </section>
  <div class="border-btn mt-30 bg-white"><span></span></div>
   <section class="bg-white">
	<div class="container mbl_containr" style="padding-bottom:0">
		<div class="row">
			 <h1 class="subtitle text-center txt_blue_clr" style="margin-bottom: 25px;color:#333;">OUR STRENGTHS</h1>
			
			<ul class="strength-ul">
				<li><a href="">CLINICAL QUALITY</a></li>
				<li><a href="">TRUST & TRANSPARENCY</a></li>
				<li><a href="">RANGE OF TESTS</a></li>
				<li><a href="">LAB AUTOMATION</a></li>
				<li><a href="">TECHNOLOGY</a></li>
				<li><a href="">ACCESSIBILITY</a></li>
				<li><a href="">SERVICE EXCELLENCE</a></li>
				<li><a href="">PATIENT EXPERIENCE</a></li>
				<li><a href="">SPEED</a></li>
			</ul>
			
		</div>
	</div>
  </section>
   <div class="border-btn mt-30 bg-white"><span  style="background:#333;"></span></div>
   
   
    <section class="bg-white">
	<div class="container mbl_containr" style="padding-bottom:30px">
		<div class="row">
			 <h1 class="subtitle text-center txt_blue_clr" style="margin-bottom: 25px;color:#333;">OUR SCOPE OF WORK</h1>
			<center><p class="col-md-8 col-md-offset-2">Our stringent quality control and standardization measures ensure that you are sufficiently equipped to make accurate clinical decisions and thereby provide optimal care to your patients.</p></center>
			<div class="clearfix"></div>
			<ul class="scope-ul">
				<li><a href="">Biochemistry</a></li>
				<li><a href="">Haematology</a></li>
				<li><a href="">Immunology</a></li>
				<li><a href="">Flow cytometry</a></li>
				<li><a href="">Cytology</a></li>
				<li><a href="">Histopathology</a></li>
				<li><a href="">Microbiology</a></li>
				<li><a href="">Genetic studies</a></li>
				
			</ul>
		</div>
	</div>
  </section>
    <section class="indx_mbl_ovrlay " style="padding-bottom:0;margin-bottom:0;background:white">
        <div class="container mbl_containr" style="padding-bottom:0">
            <div class="row">
                <div class="col-sm-12 pdng_0">
                    <div class="indx_mbl_mdl">
                        <!--  <h1 class="mbl_title center">App Communication Space</h1>-->
						   
                            <div class="col-sm-4  col-xs-4">
                                <img src="<?php echo base_url(); ?>user_assets/images/new/book-test.png"/> 
                            </div>
							 <div class="col-sm-4 col-xs-4">
                                <img src="<?php echo base_url(); ?>user_assets/images/new/manage-report.png"/> 
                            </div>
							 <div class="col-sm-4 col-xs-4">
                                <img src="<?php echo base_url(); ?>user_assets/images/new/share-report.png"/> 
                            </div>
							
                           
                    </div>
                </div>
            </div>
        </div>
    </section>
	
	<section class="indx_mbl_ovrlay" style="margin-bottom:0; background:#d7d7d7; background-repeat:no-repeat; ">
        <div class="container mbl_containr">
            <div class="row">
			<div class="col-sm-12" style="text-align:center;">
			<div class="col-sm-1 col-xs-3 pdng_0 col-sm-offset-2 ">
				 <img src="<?php echo base_url(); ?>user_assets/images/new/icon-a.png"/> 
			</div>
                           <div class="col-sm-7  col-xs-9 pdng_0 ">    <h1 class="mbl_title center" style="margin-top:0px; margin-bottom:0px;">DOWNLOAD AIRMED MOBILE APP<br/> & GET <b style="font-family: 'Montserrat', sans-serif;">30% CASH BACK</B> </h1>
							  
							 </div>
							 <div class="clearfix"></div><br/>
                              <div class="col-sm-6  pdng_0 col-sm-offset-4">
							  <div class="col-sm-4  col-xs-6">
                                        <a href="https://itunes.apple.com/in/app/airmed-pathlabs/id1152367695?mt=8" target="_blank"><img class="app_full_img" src="<?php echo base_url(); ?>thumb_helper.php?h=53&w=173&src=user_assets/images/apple_appstore_big.png"/></a>
                                    </div>
                                    <div class="col-sm-4  col-xs-6">
                                        <a href="https://play.google.com/store/apps/details?id=com.patholab&hl=en" target="_blank"><img class="mbl_googl_res_mrgn app_full_img" src="<?php echo base_url(); ?>thumb_helper.php?h=54&w=173&src=user_assets/images/google_play.png"/></a>
                                    </div>
                                    
                                </div>
                            </div>
								
			</div>
        </div>
    </section>
				
                
</div>
<!-- end main-content -->
<!--<script src="<?php echo base_url(); ?>user_assets/js/jquery-2.2.0.min.js"></script>--> 
<script src="<?php echo base_url(); ?>user_assets/js/jquery-ui.min.js"></script>
<script src="<?php echo base_url(); ?>user_assets/js/bootstrap.min.js"></script>

